﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading;
using System.Threading.Tasks;

namespace Testbed_v3._03_Unit.B_Vision
{
    class Cognex: _02_Communication.A_Socket.SocketClient, IVision
    {
        public static readonly string hostEndMessage = "\r\n"; // protocol
        public EventHandler _eventVisionConnect;
        public event CMD_EVENT_HANDLER _eventCognexInsightSdk;



        public Image vision_img = new Bitmap(1280, 960);

        public bool errorFlag { get; set; }
        public string errorMessage { get; set; }
        public string successMessage { get; set; }
        public string cmdResult { get; set; }

        public string[] getResult { get; set; }
        public string[] getValue { get; set; }
        public string[,] calibResult { get; set; }
        public string robot_x { get; set; }
        public string robot_y { get; set; }
        public string jobIndex { get; set; }
        public bool connectFlag { get; set; }
        public bool online { get; set; }
        private static object _lock = new object();
        System.Windows.Forms.Timer T = new System.Windows.Forms.Timer();
        public void init()
        {
            online = false;
            errorFlag = false;
            errorMessage = ""; 
            successMessage = "";
            cmdResult = "";
            calibResult = new string[20, 2];
            robot_x = "0";
            robot_y = "0";
            connectFlag = false;
            T.Tick += new EventHandler(T_Tick);
            T.Interval = 100;

            T.Start();
        }
        private void T_Tick(object sender, EventArgs e)
        {
            connectFlag = _socketClientConnectedFlag;
        }
        public Cognex()
        {
            init();
        }
        public void VisionCmd(string command, string m_commandData = "")
        {

            lock (_lock)
            {
                SendMessage(m_commandData + hostEndMessage);
                Log.Inst._log("[VISION][SEND] : " + m_commandData + hostEndMessage, DateTime.Now, LOG_FILE_KINDS.MAIN);
                Receive_Sync();
                Log.Inst._log("[VISION][RECV] : " + dataFromServer, DateTime.Now, LOG_FILE_KINDS.MAIN);
                cmdResult = DataSorting(dataFromServer, command);

            }


        }
        public bool ErrorCheck()
        {
            if (errorFlag)
            {
                return false;
            }
            else
                return true;
        }

        public string DataSorting(string message, string command = "")
        {

            try
            {
                errorFlag = false;
                successMessage = "";
                errorMessage = "";


                if (command.StartsWith("GETONLINE"))
                {
                    message = message.Replace("\r\n", "");
                    online = Convert.ToBoolean(message);
                    successMessage = "OK";
                    return successMessage;
                }
                else if (message.StartsWith("1\r\n"))
                {
                    string[] messageSplit = message.Split(new char[2] { '\r', '\n' });
                    message = message.Replace("1\r\n", "");
                    successMessage = "OK";

                    if (command.StartsWith("GETVALUE"))
                    {
                        if (command.Contains("3"))
                        {
                            getResult = new string[4];
                            getResult[0] = ""; getResult[1] = ""; getResult[2] = "";
                            getResult[3] = messageSplit[2];
                            Console.WriteLine($"vision get value command data {messageSplit.Length}개, 1:,2:{messageSplit[2]}");

                            if (getResult[3].Contains("1"))
                            { return "NG"; }
                        }
                        else if (command.Contains("2"))
                        {
                            getResult = new string[4];
                            getResult[0] = ""; getResult[1] = ""; getResult[2] = "";
                            getResult[3] = messageSplit[3];
                            //MessageBox.Show($"command data {messageSplit.Length}개, {messageSplit[2]}, {messageSplit[3]}");

                            if (getResult[3].Contains(",1,"))
                            { return "NG"; }
                        }
                        else
                        {
                            int countComma = message.Count(f => (f == ','));
                            //X,Y,Theta,Result
                            getResult = new string[countComma + 1];

                            for (int i = 0; i < countComma + 1; i++)
                            {


                                //X,Y,Theta,Result
                                getResult[i] = messageSplit[2].Split(',')[i].Trim();
                            }
                            Console.WriteLine($"ng vison : {getResult[0]}");
                            if (getResult[3].Contains("1"))
                            {

                                return "NG";
                            }
                        }

                    }
                    else if (command.StartsWith("GETPOSITION"))
                    {
                        message = message.Replace("\r\n", "");
                        if (command.Contains("X"))
                        {
                            int m_index = Convert.ToInt32(command.Replace("GetPositionX", ""));

                            calibResult[m_index, 0] = message;

                        }
                        else if (command.Contains("Y"))
                        {
                            int m_index = Convert.ToInt32(command.Replace("GetPositionY", ""));

                            calibResult[m_index, 1] = message;

                        }
                        else
                        {
                            int m_index = Convert.ToInt32(command.Replace("GetPositionTH", ""));

                            calibResult[m_index, 2] = message;

                        }
                        return successMessage;
                    }
                    else if (command.StartsWith("GETJOB"))
                    {
                        message = message.Replace("\r\n", "");
                        jobIndex = message;
                    }

                    return successMessage;
                }


                else
                {
                    errorFlag = true;
                    Console.WriteLine("Vision data sorting ERROR!!!");
                    //MessageBox.Show("Vision data sorting ERROR!!!");
                    if (dataFromServer.Contains("0"))
                    {
                        errorMessage = $"VisionError:<{command}>, Unrecognized command";
                    }
                    #region Cognex vision error
                    else if (dataFromServer.Contains("-1"))
                    {
                        if (command.StartsWith("GetValue") || command.StartsWith("SetFloat"))
                        {
                            errorMessage = $"VisionError:<{command}>, The Symbolic Tag is invalid";
                        }
                        else if (command.StartsWith("LoadFile") || command.StartsWith("StoreFile"))
                        {
                            errorMessage = $"VisionError:<{command}>,The filename is missing.";
                        }
                        else if (command.StartsWith("SetEvent"))
                        {
                            errorMessage = $"VisionError:<{command}>,The number is either out of range (0to 8) or not an integer.";
                        }
                        else if (command.StartsWith("SetString") || command.StartsWith("GETVALUE"))
                        {
                            errorMessage = $"VisionError:<{command}>,The cell ID is invalid.";
                        }
                        else if (command.StartsWith("SetOnline"))
                        {
                            errorMessage = $"VisionError:<{command}>,The value given for Int is either out of range, or is not a valid integer";
                        }
                        else if (command.StartsWith("SetJob"))
                        {
                            errorMessage = $"VisionError:<{command}>,The ID is less than 0, or is not an integer.";
                        }
                        else if (command.StartsWith("SetInteger"))
                        {
                            errorMessage = $"VisionError:<{command}>,The EasyBuilder Name is invalid, or was not an Integer Data Type.";
                        }

                    }
                    else if (dataFromServer.Contains("-2"))
                    {
                        if (command.StartsWith("GetValue") || command.StartsWith("SetEvent") || command.StartsWith("SetOnline"))
                        {
                            errorMessage = $"VisionError:<{command}>,The command could not be excuted";
                        }
                        else if (command.StartsWith("LoadFile") || command.StartsWith("SetJob"))
                        {
                            errorMessage = $"VisionError:<{command}>,The job failed to load, the vision system is Online, or the file was not found";
                        }
                        else if (command.StartsWith("GetJob"))
                        {
                            errorMessage = $"VisionError:<{command}>, The active job has been saved or does not have a numerical prefix, therefore the command could not be executed";
                        }
                        else if (command.StartsWith("StoreFile"))
                        {
                            errorMessage = $"VisionError:<{command}>,The job failed to save, the vision system is Onlineor the file was not found, therefore the command could not be executed.";
                        }
                        else if (command.StartsWith("SetFloat"))
                        {
                            errorMessage = $"VisionError:<{command}>,The command could not be executed, or the specified floating point value is outside of the control's valid range. For example,the specified name may not contain a control of the valid Data Type.";
                        }
                        else if (command.StartsWith("SetString"))
                        {
                            errorMessage = $"VisionError:<{command}>,The input string is longer than the specifiedmaximum string length in the EditString function or the cell does notcontain an EditString function. ";
                        }
                        else if (command.StartsWith("SetInteger"))
                        {
                            errorMessage = $"VisionError:<{command}>,The command could not be executed, or thespecified integer value is outside of the control's valid range. For example,the specified name may not contain a control of the valid Data Type.";
                        }
                    }
                    else if (dataFromServer.Contains("-4"))
                    {
                        if (command.StartsWith("LoadFile"))
                        {
                            errorMessage = $"VisionError:<{command}>,The vision system is out of memory.";
                        }
                        else if (command.StartsWith("SetJob"))
                        {
                            errorMessage = $"VisionError:<{command}>,The In-Sight sensor is out of memory.";

                        }

                    }
                    else if (dataFromServer.Contains("-5"))
                    {
                        if (command.StartsWith("SetOnline"))
                        {
                            errorMessage = $"VisionError:<{command}>,The communications flag was successfulbut the sensor did not go Online because the sensor is set Offline manuallythrough the In-Sight Explorer user interface or by a Discrete I/O signal";
                        }
                        else if (command.StartsWith(""))
                        {
                            errorMessage = $"VisionError:<{command}>,";

                        }

                    }
                    else if (dataFromServer.Contains("-6"))
                    {
                        errorMessage = $"VisionError:<{command}>,User does not have FullAccess to execute the command. For more information, see User Access Settings Dialog";

                    }
                    else
                    {
                        errorMessage = $"VisionError:<{command}>, CodeError Datasorting Error";
                    }

                    return errorMessage;
                }
                #endregion
            }
            catch
            {
                errorFlag = true;
                Console.WriteLine("Vision data sorting ERROR!!!");
                //MessageBox.Show("Vision data sorting ERROR!!!");
                errorMessage = "Vision dataSorting Code Error";
                return errorMessage;
            }
        }


        public bool VisionConnect(String hostName, UInt16 hostPort, String hostId = "admin", String hostPw = "")
        {
            Connect(hostName, hostPort);
            Thread.Sleep(200);
            Receive_Sync();
            lock (_lock)
            {

                if (dataFromServer.Contains("Welcome"))
                {
                    VisionCmd("CONNECT", hostId); // ID
                    VisionCmd("CONNECT", hostPw); //PW
                                                  //_eventVisionConnect

                    Thread.Sleep(100);
                    string msg = "Cognex vision Connected";
                    Log.Inst._log(msg, DateTime.Now, LOG_FILE_KINDS.VISION);
                    return true;
                }
                else
                {
                    string msg = "Cognex vision Connect Admin IDnPW Error";
                    Log.Inst._log(msg, DateTime.Now, LOG_FILE_KINDS.MAIN, LOG_KINDS.ERROR);
                    Console.WriteLine(msg);
                    return false;
                }
            }
        }

        public bool Trigger()
        {
            VisionCmd("TRIGGER", "SE8");
            return ErrorCheck();
        }

        public bool CaseResult(int m_case)
        {
            string m_value = "Result";
            if (m_case != 0 && m_case != 3)
            {
                m_value = m_value + m_case.ToString();
            }

            return GetValue(m_value, m_case);
        }

        public bool SelectCase(int m_case)
        {
            SetInteger("Case", m_case.ToString());
            return ErrorCheck();
        }
        #region basically Command (cognex origin command)
        // Cognex 기본 명령어 List
        /// <summary>
        ///  GetJob, GetOnline, GetValue(encoded location / Sysmbolic Name), Load File, Set Event, Store File, Set Float, Set Integer, Set Job, Set Online, Set String
        /// </summary>
        /// 
        public bool GetJob()
        {
            VisionCmd("GETJOB", "GJ");
            return ErrorCheck();
        }
        public bool GetOnline()
        {
            VisionCmd("GETONLINE", "GO");
            cmdResult = DataSorting(dataFromServer, "GetOnline");
            return ErrorCheck();
        }

        public bool GetValue(string m_symbolTag, int selectedCase = 0)
        {
            VisionCmd("GETVALUE" + selectedCase.ToString(), "GV" + m_symbolTag);
            return ErrorCheck();
        }
        public bool LoadFile(string m_filename)
        {
            VisionCmd("LOADFILE", "LF" + m_filename);
            return ErrorCheck();
        }
        public bool SetEvent(string m_eventCode)
        { // m_event code 8 =  Acquirean image and update the spreadsheet. This option requires the AcquireImagefunction's Trigger parameter tobe set to External, Manual or Network
            VisionCmd("SETEVENT", "SE" + m_eventCode);
            return ErrorCheck();
        }
        public bool StoreFile(string m_filename)
        {
            VisionCmd("STOREFILE", "TF" + m_filename);
            return ErrorCheck();

        }
        public bool SetFloat(string m_symbolicTag, string m_value)
        {
            VisionCmd("SETFLOAT", "SF" + m_symbolicTag + " " + m_value);
            return ErrorCheck();
        }

        public bool SetInteger(string m_name, string m_value)
        {
            VisionCmd("SETINTEGER", "SI" + m_name + " " + m_value);
            return ErrorCheck();
        }
        public bool SetString(string m_column, string m_row, string m_value)
        {
            VisionCmd("SETSTRING", "SS" + m_column + m_row + m_value);
            return ErrorCheck();
        }
        public bool SetJob(string m_jobID)
        {
            VisionCmd("SETJOB", "SJ" + m_jobID);
            return ErrorCheck();
        }

        public bool SetOnline(string m_onOff)
        {
            VisionCmd("SETONLINE", "SO" + m_onOff);


            return ErrorCheck();
        }
        #endregion

        /*
        public bool GetPos_Cal(int m_index, string m_desireValue = "")
        {
            if (m_desiredValue == "") //X,Y 같이구하는 sequence 
            {
                VisionCmd("SFPX_" + m_index.ToString() + robot_x);
                cmdResult = DataSorting(dataFromServer, "GetPositionX" + m_index.ToString());
                Log.Instance._log("[CMDR] : X =" + dataFromServer + cmdResult, DateTime.Now, LOG_FILE_KINDS.VISION);
                if (cmdResult == "OK")
                {
                    VisionCmd("SFPY_" + m_index.ToString() + robot_y);
                    cmdResult = DataSorting(dataFromServer, "GetPositionY" + m_index.ToString());
                    Log.Instance._log("[CMDR] : Y=" + dataFromServer + cmdResult, DateTime.Now, LOG_FILE_KINDS.VISION);
                    Console.WriteLine("Y축 값 받아오기");
                    return ErrorCheck();
                }
                else
                {
                    errorFlag = true;
                    Console.WriteLine(cmdResult);
                }
            }
            else if (m_desiredValue == "X")  // 단일 X 만구하는 sequence
            {
                VisionCmd("SFPX_" + m_index.ToString() + robot_x);
                cmdResult = DataSorting(dataFromServer, "GetPositionX" + m_index.ToString());
                Log.Instance._log("[CMDR] : X =" + dataFromServer + cmdResult, DateTime.Now, LOG_FILE_KINDS.VISION);
                Console.WriteLine("X축 값 받아오기");
                return ErrorCheck();
            }
            else if (m_desiredValue == "Y")
            {
                VisionCmd("SFPY_" + m_index.ToString() + robot_y);
                cmdResult = DataSorting(dataFromServer, "GetPositionY" + m_index.ToString());
                Log.Instance._log("[CMDR] : Y=" + dataFromServer + cmdResult, DateTime.Now, LOG_FILE_KINDS.VISION);
                Console.WriteLine("Y축 값 받아오기");
                return ErrorCheck();
            }
            else if (m_desiredValue == "TH")
            {
                VisionCmd("SFPTH_" + m_index.ToString() + robot_y);
                cmdResult = DataSorting(dataFromServer, "GetPositionTH" + m_index.ToString());
                Log.Instance._log("[CMDR] : TH=" + dataFromServer + cmdResult, DateTime.Now, LOG_FILE_KINDS.VISION);
                return ErrorCheck();
            }
        }
        */
        /*
        public bool Connect_sdk(int vision, UInt16 hostPort, String hostId = "admin", String hostPw = "")
        {
            ConnectToServer(ParamReciepe._visionIP[vision], hostPort);
            Receive_Sync();
            if (dataFromServer.Contains("Welcome"))
            {

                VisionCmd(hostId); // ID
                VisionCmd(hostPw); //PW
                //_eventVisionConnect
                string msg = "Cognex vision Connected";
                Log.Instance._log(msg, DateTime.Now, LOG_FILE_KINDS.VISION);
                return true;
            }
            else
            {
                string msg = "Cognex vision Connect Admin IDnPW Error";
                Log.Instance._log(msg, DateTime.Now, LOG_FILE_KINDS.VISION, LOG_KINDS.ERROR);
                Console.WriteLine(msg);
                return false;
            }
        }
        */





      
    }
}
