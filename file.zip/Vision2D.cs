﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Diagnostics;
using System.Linq;
using System.IO;
using System.Threading;
using System.Text;
using System.Threading.Tasks;
using System.Drawing.Imaging;
using Microsoft.ML;
using static Microsoft.ML.Transforms.Image.ImageResizingEstimator;
using Testbed_v3._03_Unit.B_Vision.DataStructures;
using SpinnakerNET;
using SpinnakerNET.GenApi;
using Testbed_v3._04_Task.A_Factory;
using OpenCvSharp;
using LGDigitalParkP3;

namespace Testbed_v3._03_Unit.B_Vision
{
    public class Vision2D
    {
        static PredictionEngine<YoloV4BitmapData, YoloV4Prediction> predictionEngine;
        static readonly string[] className = new string[] { "1", "2" };
        // 임시 이미지
        static string imgName = "tmpImg.bmp";
        static public Bitmap resultImg { get; set; }
        public static List<PointVision> coordinates = new List<PointVision>();

        static ManagedCameraList camList;

        static int final_category;
        public struct PointVision
        {
            public int Category { get; }
            public int NumIndex { get; }
            public int X { get; }
            public int Y { get; }
            public PointVision(int category, int numIndex, int x, int y)
            {
                Category = category;
                NumIndex = numIndex;
                X = x;
                Y = y;
            }
        }

        // 초기화 성공시 1, 실패시 0 반환
        public int initializeCamera()
        {
            int result = 1;
            INodeMap nodeMapTLDevice;
            INodeMap nodeMap;

            FileStream fileStream;
            try
            {
                fileStream = new FileStream(@"test.txt", FileMode.Create);
                fileStream.Close();
                File.Delete("test.txt");
            }
            catch
            {
                Console.WriteLine("Failed to create file in current folder. Please check permissions.");
                Console.WriteLine("Press enter to exit...");
                Console.ReadLine();
                return 0;
            }

            // Retrieve singleton reference to system object
            ManagedSystem system = new ManagedSystem();

            camList = system.GetCameras();

            Console.WriteLine("Number of cameras detected: {0}\n", camList.Count);

            // Finish if there are no cameras
            if (camList.Count == 0)
            {
                // Clear camera list before releasing system
                camList.Clear();

                // Release system
                system.Dispose();

                Console.WriteLine("Not enough cameras!");
                Console.WriteLine("Done! Press Enter to exit...");
                Console.ReadLine();

                return 0;
            }
            else
            {
                try
                {
                    nodeMapTLDevice = camList[0].GetTLDeviceNodeMap();

                    //result = PrintDeviceInfo(nodeMapTLDevice);

                    // Initialize camera
                    camList[0].Init();

                    // Retrieve GenICam nodemap
                    nodeMap = camList[0].GetNodeMap();
                }
                catch
                {

                }
            }

            try
            {
                //camList[0].BeginAcquisition();
            }
            catch (SpinnakerException ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
                result = 0;
            }

            return result;
        }

        // ONNX 파일 경로 지정 필요
        public void loadModelFile(string modelPath)
        {
            string _modelPath = modelPath;

            MLContext mlContext = new MLContext();

            var pipeline = mlContext.Transforms.ResizeImages(inputColumnName: "bitmap", outputColumnName: "images", imageWidth: 640, imageHeight: 640, resizing: ResizingKind.Fill)
                .Append(mlContext.Transforms.ExtractPixels(outputColumnName: "images", scaleImage: 1f / 255f, interleavePixelColors: false))
                .Append(mlContext.Transforms.ApplyOnnxModel(_modelPath));

            var model = pipeline.Fit(mlContext.Data.LoadFromEnumerable(new List<YoloV4BitmapData>()));
            predictionEngine = mlContext.Model.CreatePredictionEngine<YoloV4BitmapData, YoloV4Prediction>(model);
        }

        //[0] = X좌표, [1] = Y좌표, [2] = 찾기 성공 유무 (1일경우 찾음, 0일경우 못찾음)
        //인자값: 스코어 Threshold, IOU Threshold값 (박스교차정도)
        public Bitmap acquireImage()
        {
            try
            {
                camList[0].BeginAcquisition();
                Thread.Sleep(300);
                IManagedImage rawImage = camList[0].GetNextImage(0);       
                {
                    if (rawImage.IsIncomplete)
                    {
                        Console.WriteLine("Image incomplete with image status {0}...", rawImage.ImageStatus);
                    }
                    else
                    {
                        uint width = rawImage.Width;
                        uint height = rawImage.Height;
                        var image = rawImage.Convert(PixelFormatEnums.Mono8);
                        Bitmap bitmapImage = image.bitmap;
                        //Bitmap maksedBitmapImage = masking(bitmapImage);
                        rawImage.Release();
                        camList[0].EndAcquisition();
                        return bitmapImage;
                    }
                }
                return null;
            }
            catch
            {
                return null;
            }
        }

        private Bitmap masking(Bitmap picture)
        {
            Mat img = OpenCvSharp.Extensions.BitmapConverter.ToMat(picture);
            List<List<OpenCvSharp.Point>> listOfListOfPoint = new List<List<OpenCvSharp.Point>>();
            List<OpenCvSharp.Point> listOfPoint = new List<OpenCvSharp.Point>();
            listOfPoint.Add(new OpenCvSharp.Point(1700, 580));
            listOfPoint.Add(new OpenCvSharp.Point(1188, 754));
            listOfPoint.Add(new OpenCvSharp.Point(1512, 1673));

            listOfListOfPoint.Add(listOfPoint);
            Cv2.Polylines(img, listOfListOfPoint, false, Scalar.White, 70);

            List<List<OpenCvSharp.Point>> listOfListOfPoint2 = new List<List<OpenCvSharp.Point>>();
            List<OpenCvSharp.Point> listOfPoint2 = new List<OpenCvSharp.Point>();

            listOfPoint2.Add(new OpenCvSharp.Point(1059, 815));
            listOfPoint2.Add(new OpenCvSharp.Point(552, 970));
            listOfPoint2.Add(new OpenCvSharp.Point(855, 1910));

            listOfListOfPoint2.Add(listOfPoint2);
            Cv2.Polylines(img, listOfListOfPoint2, false, Scalar.White, 70);

            Bitmap bt = OpenCvSharp.Extensions.BitmapConverter.ToBitmap(img);

            return bt;
        }

        public void inferObjectPosition(out Vision2DResult Vision2DResult, float threshold = 0.45f, float IOUthreshold = 0.07f)
        {
            //List<Point> coordinates = new List<Point>();
            string currentDirectory = System.IO.Directory.GetCurrentDirectory();
            //const string imageFolder = @"D:\Code\02. CS\Special\Yolov5CSONNX\YOLOv4MLNet-yolo-v5-incl_0910\YOLOv4MLNet\bin\x64\Debug\net5.0";
            //string imageFolder = currentDirectory;
            Vision2DResult = new Vision2DResult();

            var bitmap = new Bitmap(acquireImage());
            {
                bitmap = masking(bitmap);
                // predict
                var predict = predictionEngine.Predict(new YoloV4BitmapData() { Image = bitmap });
                var results = predict.GetResults(className, threshold, IOUthreshold);
                using (var g = Graphics.FromImage(bitmap))
                {
                    int num_cat1 = 0;
                    int num_cat2 = 0;
                    int category = -1;

                    foreach (var res in results)
                    {
                        // draw predictions
                        var x1 = res.BBox[0];
                        var y1 = res.BBox[1];
                        var x2 = res.BBox[2];
                        var y2 = res.BBox[3];
                        g.DrawRectangle(Pens.Red, x1, y1, x2 - x1, y2 - y1);
                        using (var brushes = new SolidBrush(Color.FromArgb(50, Color.Red)))
                        {
                            g.FillRectangle(brushes, x1, y1, x2 - x1, y2 - y1);
                        }

                        g.DrawString(res.Label + " " + res.Confidence.ToString("0.00"),
                                        new Font("Arial", 12), Brushes.Blue, new PointF(x1, y1));
                        //g.DrawString(num.ToString(), new Font("Arial", 15), Brushes.Blue, new PointF(x1, y1));
                        if (Convert.ToInt32(res.Label) == 1)
                        {
                            num_cat1 = num_cat1 + 1;
                            Console.WriteLine($"cat1: {num_cat1}, X: {(int)(x1 + x2) / 2}, Y: {(int)(y1 + y2) / 2}");
                            category = 1;
                            coordinates.Add(new PointVision(category, num_cat1, (int)(x1 + x2) / 2, (int)(y1 + y2) / 2));
                        }

                        if (Convert.ToInt32(res.Label) == 2)
                        {
                            num_cat2 = num_cat2 + 1;
                            Console.WriteLine($"cat2: {num_cat2}, X: {(int)(x1 + x2) / 2}, Y: {(int)(y1 + y2) / 2}");
                            category = 2;
                            coordinates.Add(new PointVision(category, num_cat2, (int)(x1 + x2) / 2, (int)(y1 + y2) / 2));

                        }
                    }
                    resultImg = bitmap;
                    resultImg.Save("D://tmp.gif", System.Drawing.Imaging.ImageFormat.Gif);

                    int minimum1 = 99999999;
                    int minimum2 = 99999999;
                    int final_index1 = 0;
                    int final_index2 = 0;
                    int finalX1 = 0;
                    int finalY1 = 0;
                    int finalX2 = 0;
                    int finalY2 = 0;
                    int isFound = 0;

                    double[] coord = new double[3];

                    foreach (var point in coordinates)
                    {
                        if (point.Category == 1)
                        {
                            int current = (int)Math.Sqrt((point.X * point.X) + (point.Y * point.Y));
                            if (current < minimum1)
                            {
                                minimum1 = current;
                                final_index1 = point.NumIndex;
                                finalX1 = point.X;
                                finalY1 = point.Y;
                                final_category = 1;
                                coord = Calc(final_category, finalX1, finalY1);
                                isFound = 1;

                            }
                        }

                        if (point.Category == 2)
                        {
                            int current = (int)Math.Sqrt((point.X * point.X) + (point.Y * point.Y));
                            if (current < minimum2)
                            {
                                minimum2 = current;
                                final_index2 = point.NumIndex;
                                finalX2 = point.X;
                                finalY2 = point.Y;
                                final_category = 2;
                                coord = Calc(final_category, finalX2, finalY2);
                                isFound = 1;
                            }
                        }
                    }

                    if (isFound == 1)
                    {
                        Vision2DResult.isFound = 1;
                    }
                    else
                    {
                        Vision2DResult.isFound = 0;
                    }

                    minimum1 = 99999999;
                    minimum2 = 99999999;
                    isFound = 0;
                    Log.Inst._log($"Cat1 Index: {final_index1}, X: {finalX1}, Y:{finalY1}", DateTime.Now, LOG_FILE_KINDS.MAIN);
                    Log.Inst._log($"Cat2 Index: {final_index2}, X: {finalX2}, Y:{finalY2}", DateTime.Now, LOG_FILE_KINDS.MAIN);
                    Console.WriteLine("Number Found: " + coordinates.Count);
                    Console.WriteLine($"Cat1 Index: {final_index1}, X: {finalX1}, Y:{finalY1}");
                    Console.WriteLine($"Cat2 Index: {final_index2}, X: {finalX2}, Y:{finalY2}");

                    

                    //좌표 변환
                    //Category 1 Transitbolt
                    double[] Tool_dim_1 = new double[4];//단위[m]
                    Tool_dim_1[0] = 0.000;
                    Tool_dim_1[1] = 0.000;
                    Tool_dim_1[2] = 0.375;

                    double[] Tool_offset_1 = new double[4]; //툴좌표계 기준 단위[m]
                    Tool_offset_1[0] = 0.0112 - 0.003;
                    Tool_offset_1[1] = -0.0063;
                    Tool_offset_1[2] = 0.0301 -0.015;

                    double[] angle_find_1 = new double[3]; //단위[deg]
                    angle_find_1[0] = 18.0;      // X축 회전
                    angle_find_1[1] = 18.0;      // Y축 회전 
                    angle_find_1[2] = 0.0;      // Z축 회전

                    double[] angle_offset_1 = new double[3];
                    angle_offset_1[0] = 331.05;      // X축 회전
                    angle_offset_1[1] = -7.48;      // Y축 회전 
                    angle_offset_1[2] = -13.29;      // Z축 회전

                    //Category 2 Transitbolt
                    double[] Tool_dim_2 = new double[4];//단위[m]
                    Tool_dim_2[0] = 0.000;
                    Tool_dim_2[1] = 0.000;
                    Tool_dim_2[2] = 0.375;

                    double[] Tool_offset_2 = new double[4]; //툴좌표계 기준 단위[m]
                    Tool_offset_2[0] = 0.0171 - 0.004;
                    Tool_offset_2[1] = 0.011 - 0.031;
                    Tool_offset_2[2] = 0.047 + 0.003;

                    double[] angle_find_2 = new double[3]; //단위[deg]
                    angle_find_2[0] = 18.0;      // X축 회전
                    angle_find_2[1] = 18.0;      // Y축 회전 
                    angle_find_2[2] = 0.0;      // Z축 회전

                    double[] angle_offset_2 = new double[3];
                    angle_offset_2[0] =  331.05;      // X축 회전
                    angle_offset_2[1] =  -7.48;      // Y축 회전 
                    angle_offset_2[2] = -13.29;      // Z축 회전

                    //coord = Calc(final_category,finalX1, finalY1);

                    double[] cam_coord = new double[6];

                    cam_coord[0] = coord[0];//0.102953;
                    cam_coord[1] = coord[1];// -0.07372;
                    cam_coord[2] = coord[2];// 1.088791;


                    double[] translationDouble = new double[3] { -0.186646, 0.824601, 0.299725 };
                    double[] rotationDouble = new double[3] { -179.99, 0.002, -92.301 };

                    string path = @"D:\Testbed_v3\bin\Debug\net5.0-windows\T.txt"; //path 경로 설정        
                    string temp = File.ReadAllText(path); //Hand-Eye parameter 
                    string[] textValues = temp.Split(',');
                    double[] values = new double[16];
                    for (int i = 0; i < textValues.Length; i++)
                    {
                        values[i] = Convert.ToDouble(textValues[i]);

                    }
                    Mat T_HandEye = new Mat(4, 4, MatType.CV_64FC1, values);
                    double[] pos = new double[6];

                    if (final_category == 1)
                    {
                        pos = LGDigitalParkP3.Yaskawa.C2B2(translationDouble, rotationDouble, Tool_dim_1, Tool_offset_1, angle_find_1, angle_offset_1, cam_coord, T_HandEye);
                    }
                    if (final_category == 2)
                    {
                        pos = LGDigitalParkP3.Yaskawa.C2B2(translationDouble, rotationDouble, Tool_dim_2, Tool_offset_2, angle_find_2, angle_offset_2, cam_coord, T_HandEye);
                    }


                    Vision2DResult.X = pos[0] * 1000;
                    Vision2DResult.Y = pos[1] * 1000;
                    Vision2DResult.Z = pos[2] * 1000;
                    Vision2DResult.Rx = pos[3];
                    Vision2DResult.Ry = pos[4];
                    Vision2DResult.Rz = pos[5];



                    Console.WriteLine($"X: {Vision2DResult.X}");
                    Console.WriteLine($"X: {Vision2DResult.Y}");
                    Console.WriteLine($"X: {Vision2DResult.Z}");
                    Console.WriteLine($"X: {Vision2DResult.Rx}");
                    Console.WriteLine($"X: {Vision2DResult.Ry}");
                    Console.WriteLine($"X: {Vision2DResult.Rz}");
                    Log.Inst._log($"{Vision2DResult.X}", DateTime.Now, LOG_FILE_KINDS.MAIN);

                    bitmap.Dispose();
                }
                
            }

        }
       
        private double[] Calc(int category, double x, double y)
        {
            //1:1 대응
            double[] A = new double[3] { x, y, 1 };
            Mat Image_C = new Mat(3, 1, MatType.CV_64FC1, A);
            double[] H2 = new double[9] {1947.65, 1245.61, 1108.45, -1290.35, 1794.78, 1557.29, 0.0443271, -0.0801462, 1.08443 };
            Mat m1 = new Mat(3, 3, MatType.CV_64FC1, H2);
            Mat I_H = m1.Inv();
            Mat W_C_I = I_H * Image_C;
            W_C_I.Set<double>(0, W_C_I.At<double>(0) / W_C_I.At<double>(2));
            W_C_I.Set<double>(1, W_C_I.At<double>(1) / W_C_I.At<double>(2));
            W_C_I.Set<double>(2, W_C_I.At<double>(2) / W_C_I.At<double>(2));

            //외부 파라미터 변경 여부 테스트 필요
            double[] B = new double[16];
            if (category == 1)
            {
                 B = new double[16] {0.815225, 0.579052, 0.0103157, -0.0991462, -0.577445, 0.811342, 0.0910049, 0.194776, 0.04432, -0.08014, 0.995797, 1.08443, 0, 0, 0, 1 };
            }
            if (category == 2)
            {
                B = new double[16] { 0.815225, 0.579052, 0.0103157, -0.0991462, -0.577445, 0.811342, 0.0910049, 0.194776, 0.04432, -0.08014, 0.995797, 1.08443, 0, 0, 0, 1 };
            }

            Mat Image_E = new Mat(4, 4, MatType.CV_64FC1, B);
            Mat E_H = new Mat(4, 1, MatType.CV_64FC1);
            E_H.Set<double>(0, W_C_I.At<double>(0));
            E_H.Set<double>(1, W_C_I.At<double>(1));
            E_H.Set<double>(2, 0);
            E_H.Set<double>(3, W_C_I.At<double>(2));
            Mat W_C_E = Image_E * E_H;
  
            Mat Robot_Coordinates = new Mat(4, 1, MatType.CV_64FC1);

            Robot_Coordinates =  W_C_E;

            Console.WriteLine(Robot_Coordinates.At<double>(0).ToString() + " , " + Robot_Coordinates.At<double>(1).ToString() + " , "
                + Robot_Coordinates.At<double>(2).ToString() + " , " + Robot_Coordinates.At<double>(3).ToString());

            double[] result = new double[3] { Robot_Coordinates.At<double>(0), Robot_Coordinates.At<double>(1), Robot_Coordinates.At<double>(2) };

            return result;
        }
        //결과 이미지 저장(경로, 파일이름 지정)
        public void saveResultImg(string directory, string imgName)
        {
            //resultImg.Save(Path.Combine(directory, Path.ChangeExtension(imgName, "_processed" + Path.GetExtension(imgName))));
            resultImg.Save("D://tmp.gif", System.Drawing.Imaging.ImageFormat.Gif);

        }
    }
}
