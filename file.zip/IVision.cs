﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Testbed_v3._03_Unit.B_Vision
{
    public interface IVision
    {
        public bool errorFlag { get; set; }
        public string errorMessage { get; set; }
        public string successMessage { get; set; }
        public string cmdResult { get; set; }

        public string[] getResult { get; set; }
        public string[] getValue { get; set; }
        public string[,] calibResult { get; set; }
        public string robot_x { get; set; }
        public string robot_y { get; set; }
        public string jobIndex { get; set; }

        public bool online { get; set; }
        public bool connectFlag { get; set; }


        public void VisionCmd(string command, string m_commandData = "");
        public string DataSorting(string message, string command = "");
        public bool VisionConnect(String hostName, UInt16 hostPort, String hostId = "admin", String hostPw = "");
        public bool Trigger();
        public bool CaseResult(int m_case);
        public bool SelectCase(int m_case);
        public bool GetJob();

        public bool GetOnline();
        public bool GetValue(string m_symbolTag, int selectedCase = 0);

        public bool LoadFile(string m_filename);


        public bool SetEvent(string m_eventCode);
        public bool StoreFile(string m_filename);
        public bool SetFloat(string m_symbolicTag, string m_value);

        public bool SetInteger(string m_name, string m_value);
        public bool SetString(string m_column, string m_row, string m_value);
        public bool SetJob(string m_jobID);
        public bool SetOnline(string m_onOff);
    }
}
